// -----------------------------------------------------------------------------
// APP NAME AND VERSION
// -----------------------------------------------------------------------------

#pragma once

#define APP_NAME                "ESPURNA"
#define APP_VERSION             "1.15.0-dev"
#define APP_AUTHOR              "xose.perez@gmail.com"
#define APP_WEBSITE             "http://tinkerman.cat"
#define CFG_VERSION             5
