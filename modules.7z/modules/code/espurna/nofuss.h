/*

NOFUSS MODULE

Copyright (C) 2016-2019 by Xose Pérez <xose dot perez at gmail dot com>

*/

#include "espurna.h"

#if NOFUSS_SUPPORT

#include <NoFUSSClient.h>

void nofussSetup();

#endif // NOFUSS_SUPPORT
