/*

SETTINGS MODULE

*/

#pragma once

#include <Arduino.h>
#include <cstdlib>

