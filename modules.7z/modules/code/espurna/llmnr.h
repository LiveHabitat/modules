/*

LLMNR MODULE

Copyright (C) 2017-2019 by Xose Pérez <xose dot perez at gmail dot com>

*/

#include "espurna.h"

#if LLMNR_SUPPORT

#include <ESP8266LLMNR.h>
void llmnrSetup();

#endif // LLMNR_SUPPORT
